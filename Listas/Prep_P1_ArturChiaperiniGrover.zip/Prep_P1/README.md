# Exam P1 - Exercises Preparation

The following exercises belong to studying list for the first exam P1 of Data Structures and Algorithms lecture.
Implementations are done in C.

# Organization

Each folder have the relevant files to solve the exercises.
Exercises statement are written on the README.md of each one.
